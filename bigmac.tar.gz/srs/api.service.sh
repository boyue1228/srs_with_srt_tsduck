#!/bin/bash
cd /tmp/srs/trunk/research/api-server
/usr/bin/python server.py 8085 
