#!/bin/bash

/usr/local/bin/tsorts  /videofifo.ts /null.ts > /videofifo2.ts
